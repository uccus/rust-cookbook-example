mod example_a;

fn main() {
    example_a::test();
}
